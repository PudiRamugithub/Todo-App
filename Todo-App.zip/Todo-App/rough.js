// let inputElement = document.createElement("input");
// inputElement.type = "checkbox";
// inputElement.id = "myCheckbox";
// document.body.appendChild(inputElement);

// let labelElement = document.createElement("label");
// // labelElement.htmlFor = "myCheckbox";
// labelElement.setAttribute("for","myCheckbox");
// labelElement.textContent = "Graduated";
// document.body.appendChild(labelElement);

/* <li class="todo-item-container d-flex flex-row">
     <input type="checkbox" class="checkbox-input"/>
        <div class="d-flex flex-row label-container">
            <label for="checkboxInput" class="checkbox-label">Learn Html</label>
                 <div class="delete-icon-container">
                        <i class="far fa-trash-alt delete-icon"></i>
                 </div>
        </div>
 </li> */

//Execution context whenevery we refresh the page it will destron the unwanted data and refreshly create new varialbes and objects

/* Client side  Data Storage
 Server side data Storage

JSON
------
Json is a data represent format
client to server to client data representation
Java Script Object Notation
it supports [Number,string,object,null,boolean ,array]

.JSON.stringify()
.JSON.parse()
*/

/*
Array splice Method
---------------
arr.splice(start, DeleteCount);
start=where it will start
DeleteCount= how many elaments from start index */
